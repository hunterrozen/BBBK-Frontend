"use client";
import { useState } from "react";

export default function Login() {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:4000";
  const [email, setEmail] = useState("admin@bigbros.dev");
  const [password, setPassword] = useState("Password123!");
  const [status, setStatus] = useState("");

  async function login() {
    setStatus("Logging in...");
    const r = await fetch(`${baseUrl}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      setStatus("Error: " + JSON.stringify(data));
      return;
    }
    localStorage.setItem("bb_admin_token", data.token);
    setStatus("Logged in!");
    window.location.href = "/";
  }

  return (
    <main style={{ padding: 24, maxWidth: 520 }}>
      <h1>Admin Login</h1>
      <p style={{ opacity: 0.75 }}>This page calls the API /auth/login and stores the Bearer token locally.</p>

      <div style={{ display: "grid", gap: 12 }}>
        <label>
          Email
          <input value={email} onChange={(e) => setEmail(e.target.value)} style={{ width: "100%", padding: 10 }} />
        </label>
        <label>
          Password
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} style={{ width: "100%", padding: 10 }} />
        </label>
        <button onClick={login} style={{ padding: 12, fontWeight: 900 }}>Login</button>
        <div style={{ whiteSpace: "pre-wrap", opacity: 0.8 }}>{status}</div>
      </div>
    </main>
  );
}
