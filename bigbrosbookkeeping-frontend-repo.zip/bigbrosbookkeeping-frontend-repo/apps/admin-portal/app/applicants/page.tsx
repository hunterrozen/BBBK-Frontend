"use client";
import { useEffect, useMemo, useState } from "react";
import { AdminShell, apiFetch, useApiConfig } from "../_components/AdminShell";

type JobAppStatus = "NEW" | "IN_REVIEW" | "INTERVIEW" | "OFFER" | "REJECTED" | "HIRED";

export default function Applicants() {
  const { baseUrl, token } = useApiConfig();
  const [apps, setApps] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    const r = await apiFetch(baseUrl, token, "/jobs/applications");
    setLoading(false);
    if (!r.ok) return alert("Error: " + JSON.stringify(r.data));
    setApps(r.data.applications || []);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseUrl, token]);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return apps;
    return apps.filter((a) => JSON.stringify(a).toLowerCase().includes(needle));
  }, [apps, q]);

  async function setStatus(id: string, status: JobAppStatus) {
    const r = await apiFetch(baseUrl, token, `/jobs/applications/${id}`, {
      method: "PATCH",
      body: JSON.stringify({ status })
    });
    if (!r.ok) return alert("Error: " + JSON.stringify(r.data));
    setApps((xs) => xs.map((x) => (x.id === id ? r.data.application : x)));
  }

  return (
    <AdminShell title="Applicants">
      <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 14 }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search..." style={{ padding: 10, flex: 1 }} />
        <button onClick={load} style={{ padding: 10, fontWeight: 700 }}>{loading ? "Loading..." : "Refresh"}</button>
      </div>

      <div style={{ display: "grid", gap: 10 }}>
        {filtered.length === 0 ? (
          <div style={{ padding: 12, border: "1px solid #eee", borderRadius: 12 }}>No applicants.</div>
        ) : (
          filtered.map((a) => (
            <div key={a.id} style={{ border: "1px solid #eee", borderRadius: 12, padding: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
                <div>
                  <div style={{ fontWeight: 900 }}>{a.name} <span style={{ opacity: 0.6, fontWeight: 500 }}>({a.role})</span></div>
                  <div style={{ opacity: 0.7 }}>{a.email}</div>
                  <div style={{ opacity: 0.6, fontSize: 12 }}>Applied: {new Date(a.createdAt).toLocaleString()}</div>
                </div>

                <div style={{ display: "grid", gap: 6, minWidth: 220 }}>
                  <label style={{ fontSize: 12, opacity: 0.7 }}>Status</label>
                  <select value={a.status} onChange={(e) => setStatus(a.id, e.target.value as any)} style={{ padding: 10 }}>
                    {(["NEW","IN_REVIEW","INTERVIEW","OFFER","REJECTED","HIRED"] as JobAppStatus[]).map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>

              {a.message ? (
                <div style={{ marginTop: 10, background: "#fafafa", border: "1px solid #eee", borderRadius: 10, padding: 10 }}>
                  <b>Message</b>
                  <div style={{ whiteSpace: "pre-wrap" }}>{a.message}</div>
                </div>
              ) : null}
            </div>
          ))
        )}
      </div>
    </AdminShell>
  );
}
