"use client";
import { useEffect, useMemo, useState } from "react";
import { AdminShell, apiFetch, useApiConfig } from "../../_components/AdminShell";

export default function SubmissionsReview() {
  const { baseUrl, token } = useApiConfig();
  const [subs, setSubs] = useState<any[]>([]);
  const [q, setQ] = useState("");

  async function load() {
    const r = await apiFetch(baseUrl, token, "/forms/submissions");
    if (!r.ok) return alert("Error: " + JSON.stringify(r.data));
    setSubs(r.data.submissions || []);
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [baseUrl, token]);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return subs;
    return subs.filter((s) => JSON.stringify(s).toLowerCase().includes(needle));
  }, [subs, q]);

  return (
    <AdminShell title="Submissions Review">
      <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 14 }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search..." style={{ padding: 10, flex: 1 }} />
        <button onClick={load} style={{ padding: 10, fontWeight: 900 }}>Refresh</button>
      </div>

      <div style={{ display: "grid", gap: 10 }}>
        {filtered.length === 0 ? (
          <div style={{ padding: 12, border: "1px solid #eee", borderRadius: 12 }}>No submissions.</div>
        ) : (
          filtered.map((s) => (
            <div key={s.id} style={{ border: "1px solid #eee", borderRadius: 12, padding: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
                <div>
                  <div style={{ fontWeight: 900 }}>{s.template?.name || "Template"}</div>
                  <div style={{ opacity: 0.7 }}>Status: <b>{s.status}</b></div>
                  <div style={{ opacity: 0.6, fontSize: 12 }}>Created: {new Date(s.createdAt).toLocaleString()}</div>
                  {s.company ? <div style={{ opacity: 0.7 }}>Company: {s.company.name} ({s.companyId})</div> : null}
                  {s.companyId && !s.company ? <div style={{ opacity: 0.7 }}>CompanyId: {s.companyId}</div> : null}
                </div>
              </div>

              <div style={{ marginTop: 10 }}>
                <b>Answers</b>
                <pre style={{ margin: 0, whiteSpace: "pre-wrap", background: "#fafafa", border: "1px solid #eee", padding: 10, borderRadius: 10 }}>
                  {JSON.stringify(s.answersJson, null, 2)}
                </pre>
              </div>
            </div>
          ))
        )}
      </div>
    </AdminShell>
  );
}
