"use client";
import { useEffect, useMemo, useState } from "react";
import { AdminShell, apiFetch, useApiConfig } from "../../_components/AdminShell";

type FieldType = "text" | "textarea" | "number" | "date" | "select" | "checkbox";

type Field = {
  key: string;
  label: string;
  type: FieldType;
  required: boolean;
  options?: string[];
};

export default function FormTemplatesEditor() {
  const { baseUrl, token } = useApiConfig();
  const [templates, setTemplates] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState<string>("");

  const selected = useMemo(() => templates.find((t) => t.id === selectedId) || null, [templates, selectedId]);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [fields, setFields] = useState<Field[]>([]);

  async function load() {
    const r = await apiFetch(baseUrl, token, "/forms/templates");
    if (!r.ok) return alert("Error: " + JSON.stringify(r.data));
    setTemplates(r.data.templates || []);
    if (!selectedId && (r.data.templates || []).length) setSelectedId(r.data.templates[0].id);
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [baseUrl, token]);

  useEffect(() => {
    if (!selected) return;
    setName(selected.name || "");
    setDescription(selected.description || "");
    setFields((selected.schemaJson?.fields || []).map((f: any) => ({
      key: f.key || "",
      label: f.label || "",
      type: f.type || "text",
      required: Boolean(f.required),
      options: f.options || []
    })));
  }, [selected]);

  function addField() {
    setFields((fs) => [...fs, { key: "field_" + (fs.length + 1), label: "New field", type: "text", required: false }]);
  }

  function updateField(i: number, patch: Partial<Field>) {
    setFields((fs) => fs.map((f, idx) => (idx === i ? { ...f, ...patch } : f)));
  }

  function removeField(i: number) {
    setFields((fs) => fs.filter((_, idx) => idx !== i));
  }

  async function save() {
    const r = await apiFetch(baseUrl, token, "/forms/templates", {
      method: "POST",
      body: JSON.stringify({ name, description, fields })
    });
    if (!r.ok) return alert("Error: " + JSON.stringify(r.data));
    alert("Saved template!");
    await load();
    setSelectedId(r.data.template.id);
  }

  return (
    <AdminShell title="Form Templates Editor">
      <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 14 }}>
        <aside style={{ border: "1px solid #eee", borderRadius: 12, padding: 12, height: "fit-content" }}>
          <div style={{ fontWeight: 900, marginBottom: 10 }}>Templates</div>
          <div style={{ display: "grid", gap: 8 }}>
            {templates.map((t) => (
              <button
                key={t.id}
                onClick={() => setSelectedId(t.id)}
                style={{
                  textAlign: "left",
                  padding: 10,
                  borderRadius: 10,
                  border: "1px solid " + (t.id === selectedId ? "#999" : "#eee"),
                  background: t.id === selectedId ? "#fafafa" : "white"
                }}
              >
                <b>{t.name}</b>
                {t.description ? <div style={{ opacity: 0.7, fontSize: 12 }}>{t.description}</div> : null}
              </button>
            ))}
          </div>
          <button onClick={() => { setSelectedId(""); setName(""); setDescription(""); setFields([]); }} style={{ marginTop: 10, padding: 10, fontWeight: 800 }}>
            + New template
          </button>
        </aside>

        <section style={{ border: "1px solid #eee", borderRadius: 12, padding: 12 }}>
          <div style={{ display: "grid", gap: 10, maxWidth: 820 }}>
            <label style={{ display: "grid", gap: 6 }}>
              Template name
              <input value={name} onChange={(e) => setName(e.target.value)} style={{ padding: 10 }} />
            </label>
            <label style={{ display: "grid", gap: 6 }}>
              Description
              <input value={description} onChange={(e) => setDescription(e.target.value)} style={{ padding: 10 }} />
            </label>

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <b>Fields</b>
              <button onClick={addField} style={{ padding: 10, fontWeight: 800 }}>+ Add field</button>
            </div>

            <div style={{ display: "grid", gap: 10 }}>
              {fields.length === 0 ? (
                <div style={{ padding: 12, border: "1px dashed #ddd", borderRadius: 12, opacity: 0.8 }}>
                  No fields yet.
                </div>
              ) : (
                fields.map((f, i) => (
                  <div key={i} style={{ border: "1px solid #eee", borderRadius: 12, padding: 12, display: "grid", gap: 10 }}>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                      <label style={{ display: "grid", gap: 6 }}>
                        Key
                        <input value={f.key} onChange={(e) => updateField(i, { key: e.target.value })} style={{ padding: 10 }} />
                      </label>
                      <label style={{ display: "grid", gap: 6 }}>
                        Label
                        <input value={f.label} onChange={(e) => updateField(i, { label: e.target.value })} style={{ padding: 10 }} />
                      </label>
                      <label style={{ display: "grid", gap: 6 }}>
                        Type
                        <select value={f.type} onChange={(e) => updateField(i, { type: e.target.value as any })} style={{ padding: 10 }}>
                          {(["text","textarea","number","date","select","checkbox"] as FieldType[]).map((t) => (
                            <option key={t} value={t}>{t}</option>
                          ))}
                        </select>
                      </label>
                      <label style={{ display: "grid", gap: 6 }}>
                        Required
                        <select value={String(f.required)} onChange={(e) => updateField(i, { required: e.target.value === "true" })} style={{ padding: 10 }}>
                          <option value="false">false</option>
                          <option value="true">true</option>
                        </select>
                      </label>
                    </div>

                    {f.type === "select" ? (
                      <label style={{ display: "grid", gap: 6 }}>
                        Options (comma-separated)
                        <input
                          value={(f.options || []).join(", ")}
                          onChange={(e) => updateField(i, { options: e.target.value.split(",").map((x) => x.trim()).filter(Boolean) })}
                          style={{ padding: 10 }}
                        />
                      </label>
                    ) : null}

                    <div style={{ display: "flex", justifyContent: "flex-end" }}>
                      <button onClick={() => removeField(i)} style={{ padding: 10, fontWeight: 800 }}>
                        Remove field
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <button onClick={save} style={{ padding: 12, fontWeight: 900 }}>
              Save template
            </button>
          </div>
        </section>
      </div>
    </AdminShell>
  );
}
