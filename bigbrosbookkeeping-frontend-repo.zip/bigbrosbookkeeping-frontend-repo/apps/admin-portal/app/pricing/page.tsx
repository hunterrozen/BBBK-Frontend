"use client";
import { useState } from "react";
import { AdminShell } from "../_components/AdminShell";

type Tier = { name: string; minTx: number; maxTx: number; monthlyPrice: number };

export default function Pricing() {
  const [tiers, setTiers] = useState<Tier[]>([
    { name: "Starter", minTx: 0, maxTx: 200, monthlyPrice: 299 },
    { name: "Standard", minTx: 201, maxTx: 500, monthlyPrice: 499 },
    { name: "Premium", minTx: 501, maxTx: 1000, monthlyPrice: 899 }
  ]);

  function update(i: number, key: keyof Tier, val: string) {
    setTiers((t) =>
      t.map((x, idx) => (idx === i ? ({ ...x, [key]: key === "name" ? val : Number(val) } as Tier) : x))
    );
  }

  return (
    <AdminShell title="Pricing & Plans">
      <p>TODO: save to backend + sync Stripe Products/Prices.</p>

      <div style={{ display: "grid", gap: 12 }}>
        {tiers.map((t, i) => (
          <div key={i} style={{ border: "1px solid #ddd", borderRadius: 14, padding: 14, display: "grid", gap: 10 }}>
            <label>
              Name
              <input value={t.name} onChange={(e) => update(i, "name", e.target.value)} style={{ width: "100%", padding: 8 }} />
            </label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
              <label>
                Min tx/mo
                <input value={t.minTx} onChange={(e) => update(i, "minTx", e.target.value)} style={{ width: "100%", padding: 8 }} />
              </label>
              <label>
                Max tx/mo
                <input value={t.maxTx} onChange={(e) => update(i, "maxTx", e.target.value)} style={{ width: "100%", padding: 8 }} />
              </label>
              <label>
                Monthly $
                <input value={t.monthlyPrice} onChange={(e) => update(i, "monthlyPrice", e.target.value)} style={{ width: "100%", padding: 8 }} />
              </label>
            </div>
          </div>
        ))}
      </div>

      <button
        style={{ marginTop: 14, padding: 12, fontWeight: 700 }}
        onClick={() => alert("TODO: save to API, create/update Stripe Prices, broadcast admin event")}
      >
        Save pricing
      </button>
    </AdminShell>
  );
}
