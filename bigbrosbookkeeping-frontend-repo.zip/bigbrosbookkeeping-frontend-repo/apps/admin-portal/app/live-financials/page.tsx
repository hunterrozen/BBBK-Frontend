"use client";
import { useEffect, useState } from "react";

export default function LiveFinancialsPage() {
  const [events, setEvents] = useState([]);
  const wsUrl = process.env.NEXT_PUBLIC_WS_URL || "ws://localhost:4010";

  useEffect(() => {
    const ws = new WebSocket(wsUrl);
    ws.onmessage = (msg) => {
      try {
        const data = JSON.parse(String(msg.data));
        setEvents((x) => [data, ...x].slice(0, 100));
      } catch {}
    };
    return () => ws.close();
  }, [wsUrl]);

  return (
    <main style={{ padding: 24, maxWidth: 1000 }}>
      <h1>Live Client Financial Feed</h1>
      <p>Shows client-entered financials and other live events.</p>
      <div style={{ display: "grid", gap: 10 }}>
        {events.length === 0 ? <div>No events yet.</div> : events.map((e, i) => (
          <div key={i} style={{ border: "1px solid #ddd", borderRadius: 12, padding: 12 }}>
            <strong>{e.type}</strong> — {new Date(e.ts).toLocaleString()}
            <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(e.payload || e, null, 2)}</pre>
          </div>
        ))}
      </div>
    </main>
  );
}
