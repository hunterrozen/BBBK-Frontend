"use client";
import { useEffect, useState } from "react";
import { AdminShell, useApiConfig } from "../_components/AdminShell";

type LiveEvent = { type: string; ts: number; [k: string]: any };

export default function LiveFeed() {
  const [events, setEvents] = useState<LiveEvent[]>([]);
  const { wsUrl } = useApiConfig();

  useEffect(() => {
    if (!wsUrl) return;
    const ws = new WebSocket(wsUrl);
    ws.onmessage = (m) => {
      try {
        const ev = JSON.parse(String(m.data));
        setEvents((e) => [ev, ...e].slice(0, 200));
      } catch {}
    };
    return () => ws.close();
  }, [wsUrl]);

  return (
    <AdminShell title="Live Feed">
      <p>Connects to <code>NEXT_PUBLIC_WS_URL</code> and lists events.</p>
      <div style={{ display: "grid", gap: 10 }}>
        {events.length === 0 ? (
          <div style={{ padding: 12, border: "1px solid #eee", borderRadius: 12 }}>No events yet.</div>
        ) : (
          events.map((e, i) => (
            <div key={i} style={{ padding: 12, border: "1px solid #eee", borderRadius: 12 }}>
              <b>{e.type}</b> <span style={{ opacity: 0.7 }}>{new Date(e.ts).toLocaleString()}</span>
              <pre style={{ margin: 0, whiteSpace: "pre-wrap" }}>{JSON.stringify(e, null, 2)}</pre>
            </div>
          ))
        )}
      </div>
    </AdminShell>
  );
}
