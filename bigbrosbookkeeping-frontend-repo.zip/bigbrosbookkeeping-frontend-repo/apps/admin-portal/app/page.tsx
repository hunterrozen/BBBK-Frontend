"use client";
import { AdminShell, useApiConfig, apiFetch } from "./_components/AdminShell";
import { useEffect, useState } from "react";

export default function Page() {
  const { baseUrl, token } = useApiConfig();
  const [health, setHealth] = useState<any>(null);

  useEffect(() => {
    (async () => {
      const r = await apiFetch(baseUrl, token, "/health");
      setHealth(r);
    })();
  }, [baseUrl, token]);

  return (
    <AdminShell title="Dashboard">
      <p>Starter admin dashboard for Applicants, Employees, Forms, Payroll (scaffold), HR (scaffold).</p>
      <div style={{ padding: 12, border: "1px solid #eee", borderRadius: 12 }}>
        <b>API Health:</b>
        <pre style={{ margin: 0, whiteSpace: "pre-wrap" }}>{JSON.stringify(health, null, 2)}</pre>
      </div>
      <p style={{ opacity: 0.75 }}>
        Next steps: implement real auth UI, restrict client routes, wire Stripe billing, and connect a real payroll provider.
      </p>
    </AdminShell>
  );
}
