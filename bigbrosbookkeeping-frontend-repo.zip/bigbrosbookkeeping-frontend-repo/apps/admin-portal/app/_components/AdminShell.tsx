"use client";
import { useEffect, useState } from "react";

function getBase() {
  return process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:4000";
}
function getWs() {
  return process.env.NEXT_PUBLIC_WS_URL || "ws://localhost:4010";
}

export function useApiConfig() {
  const [token, setToken] = useState<string>("");

  useEffect(() => {
    const t = localStorage.getItem("bb_admin_token") || "";
    setToken(t);
  }, []);

  function saveToken(next: string) {
    setToken(next);
    localStorage.setItem("bb_admin_token", next);
  }

  return { baseUrl: getBase(), wsUrl: getWs(), token, saveToken };
}

export function AdminShell({ title, children }: { title: string; children: React.ReactNode }) {
  const { baseUrl, token, saveToken } = useApiConfig();

  return (
    <div style={{ display: "grid", gridTemplateColumns: "240px 1fr", minHeight: "100vh" }}>
      <aside style={{ borderRight: "1px solid #eee", padding: 16 }}>
        <div style={{ fontWeight: 900, marginBottom: 12 }}>BigBros Admin</div>

        <nav style={{ display: "grid", gap: 8 }}>
          <a href="/" style={{ textDecoration: "none" }}>Dashboard</a>
          <a href="/live-feed" style={{ textDecoration: "none" }}>Live Feed</a>
          <a href="/live-financials" style={{ textDecoration: "none" }}>Live Financials</a>
          <a href="/applicants" style={{ textDecoration: "none" }}>Applicants</a>
          <a href="/employees" style={{ textDecoration: "none" }}>Employees</a>
          <a href="/forms/templates" style={{ textDecoration: "none" }}>Form Templates</a>
          <a href="/forms/submissions" style={{ textDecoration: "none" }}>Submissions</a>
          <a href="/pricing" style={{ textDecoration: "none" }}>Pricing</a>
        </nav>

        <hr style={{ margin: "16px 0" }} />

        <div style={{ display: "grid", gap: 6 }}>
          <div style={{ fontSize: 12, opacity: 0.7 }}>API Base URL</div>
          <code style={{ fontSize: 12, opacity: 0.85 }}>{baseUrl}</code>
        </div>

        <div style={{ marginTop: 12, display: "grid", gap: 6 }}>
          <label style={{ fontSize: 12, opacity: 0.7 }}>API Token (Bearer)</label>
          <textarea
            value={token}
            onChange={(e) => saveToken(e.target.value)}
            placeholder="Paste token here..."
            rows={5}
            style={{ width: "100%", padding: 8, fontSize: 12 }}
          />
          <div style={{ fontSize: 12, opacity: 0.7 }}>
            Tip: use <code>/auth/login</code> on the API to get a token.
          </div>
        </div>
      </aside>

      <main style={{ padding: 24 }}>
        <h1 style={{ marginTop: 0 }}>{title}</h1>
        {children}
      </main>
    </div>
  );
}

export async function apiFetch(baseUrl: string, token: string, path: string, init?: RequestInit) {
  const headers: any = { ...(init?.headers || {}) };
  if (!headers["content-type"] && init?.body) headers["content-type"] = "application/json";
  if (token) headers["authorization"] = "Bearer " + token;

  const r = await fetch(baseUrl + path, { ...init, headers });
  const data = await r.json().catch(() => ({}));
  return { ok: r.ok, status: r.status, data };
}
