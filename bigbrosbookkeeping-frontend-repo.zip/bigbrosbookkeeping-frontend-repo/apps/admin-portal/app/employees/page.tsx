"use client";
import { useEffect, useMemo, useState } from "react";
import { AdminShell, apiFetch, useApiConfig } from "../_components/AdminShell";

export default function Employees() {
  const { baseUrl, token } = useApiConfig();
  const [employees, setEmployees] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [q, setQ] = useState("");

  const [create, setCreate] = useState({ companyId: "", firstName: "", lastName: "", email: "", startDate: "" });

  async function load() {
    setLoading(true);
    const r = await apiFetch(baseUrl, token, "/hr/employees");
    setLoading(false);
    if (!r.ok) return alert("Error: " + JSON.stringify(r.data));
    setEmployees(r.data.employees || []);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseUrl, token]);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return employees;
    return employees.filter((e) => JSON.stringify(e).toLowerCase().includes(needle));
  }, [employees, q]);

  async function addEmployee() {
    const r = await apiFetch(baseUrl, token, "/hr/employees", {
      method: "POST",
      body: JSON.stringify({
        companyId: create.companyId,
        firstName: create.firstName,
        lastName: create.lastName,
        email: create.email || undefined,
        startDate: create.startDate || undefined
      })
    });
    if (!r.ok) return alert("Error: " + JSON.stringify(r.data));
    setCreate({ companyId: create.companyId, firstName: "", lastName: "", email: "", startDate: "" });
    setEmployees((xs) => [r.data.employee, ...xs]);
  }

  async function directDepositLink(employeeId: string) {
    const r = await apiFetch(baseUrl, token, `/payroll/employees/${employeeId}/direct-deposit-link`, { method: "POST" });
    if (!r.ok) return alert("Error: " + JSON.stringify(r.data));
    const url = r.data.url;
    if (!url) return alert("No URL returned.");
    window.open(url, "_blank");
  }

  return (
    <AdminShell title="Employees">
      <div style={{ display: "grid", gap: 14, marginBottom: 18 }}>
        <div style={{ border: "1px solid #eee", borderRadius: 12, padding: 12 }}>
          <b>Add employee</b>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 10 }}>
            <label style={{ display: "grid", gap: 6 }}>
              Company ID
              <input value={create.companyId} onChange={(e) => setCreate((c) => ({ ...c, companyId: e.target.value }))} style={{ padding: 10 }} />
            </label>
            <label style={{ display: "grid", gap: 6 }}>
              Start date (optional)
              <input type="date" value={create.startDate} onChange={(e) => setCreate((c) => ({ ...c, startDate: e.target.value }))} style={{ padding: 10 }} />
            </label>
            <label style={{ display: "grid", gap: 6 }}>
              First name
              <input value={create.firstName} onChange={(e) => setCreate((c) => ({ ...c, firstName: e.target.value }))} style={{ padding: 10 }} />
            </label>
            <label style={{ display: "grid", gap: 6 }}>
              Last name
              <input value={create.lastName} onChange={(e) => setCreate((c) => ({ ...c, lastName: e.target.value }))} style={{ padding: 10 }} />
            </label>
            <label style={{ display: "grid", gap: 6, gridColumn: "1 / -1" }}>
              Email (optional)
              <input value={create.email} onChange={(e) => setCreate((c) => ({ ...c, email: e.target.value }))} style={{ padding: 10 }} />
            </label>
          </div>
          <button onClick={addEmployee} style={{ marginTop: 10, padding: 10, fontWeight: 800 }}>Create</button>
        </div>

        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search..." style={{ padding: 10, flex: 1 }} />
          <button onClick={load} style={{ padding: 10, fontWeight: 700 }}>{loading ? "Loading..." : "Refresh"}</button>
        </div>
      </div>

      <div style={{ display: "grid", gap: 10 }}>
        {filtered.length === 0 ? (
          <div style={{ padding: 12, border: "1px solid #eee", borderRadius: 12 }}>No employees.</div>
        ) : (
          filtered.map((e) => (
            <div key={e.id} style={{ border: "1px solid #eee", borderRadius: 12, padding: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
                <div>
                  <div style={{ fontWeight: 900 }}>{e.firstName} {e.lastName}</div>
                  <div style={{ opacity: 0.7 }}>{e.email || "—"}</div>
                  <div style={{ opacity: 0.6, fontSize: 12 }}>Created: {new Date(e.createdAt).toLocaleString()}</div>
                </div>
                <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                  <button onClick={() => directDepositLink(e.id)} style={{ padding: 10, fontWeight: 800 }}>
                    Generate direct deposit link
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </AdminShell>
  );
}
