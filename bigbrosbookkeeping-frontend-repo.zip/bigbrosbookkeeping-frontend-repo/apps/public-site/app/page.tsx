"use client";
import Image from "next/image";
import Script from "next/script";

export default function Page() {
  const gaId = process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID || "";

  return (
    <>
      {gaId ? (
        <>
          <Script src={`https://www.googletagmanager.com/gtag/js?id=${gaId}`} strategy="afterInteractive" />
          <Script id="ga-script" strategy="afterInteractive">
            {`window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', '${gaId}');`}
          </Script>
        </>
      ) : null}

      <main style={{ padding: 24, maxWidth: 1000 }}>
        <div style={{ display: "grid", gap: 16 }}>
          <Image src="/images/logo.png" alt="BigBrosBookkeeping logo" width={260} height={80} priority style={{ maxWidth: "100%", height: "auto" }} />

          <div>
            <h1>BigBrosBookkeeping</h1>
            <p>Bookkeeping, payroll, HR, billing, AI assistant, and connected banking.</p>
          </div>

          <Image src="/images/hero.jpg" alt="Hero image" width={1000} height={420} style={{ width: "100%", height: "auto", borderRadius: 16, border: "1px solid #eee" }} />

          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <a href="/careers" style={{ padding: 12, border: "1px solid #ddd", borderRadius: 12, textDecoration: "none" }}>Careers</a>
            <a href="/pricing" style={{ padding: 12, border: "1px solid #ddd", borderRadius: 12, textDecoration: "none" }}>Pricing</a>
            <a href={process.env.NEXT_PUBLIC_CLIENT_PORTAL_URL || "http://localhost:3002/login"} style={{ padding: 12, border: "1px solid #ddd", borderRadius: 12, textDecoration: "none" }}>Client Portal</a>
            <a href={process.env.NEXT_PUBLIC_ADMIN_PORTAL_URL || "http://localhost:3003/login"} style={{ padding: 12, border: "1px solid #ddd", borderRadius: 12, textDecoration: "none" }}>Admin Login</a>
          </div>
        </div>
      </main>
    </>
  );
}
