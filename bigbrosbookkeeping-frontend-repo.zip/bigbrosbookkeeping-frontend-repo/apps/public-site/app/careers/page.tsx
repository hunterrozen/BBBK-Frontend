export default function Careers() {
  return (
    <main style={{ padding: 24, maxWidth: 900 }}>
      <h1>Careers</h1>
      <p>Apply to work with BigBrosBookkeeping.</p>
      <form method="post" action="/api/apply" style={{ display: "grid", gap: 12, maxWidth: 520 }}>
        <label>Full name<input name="name" required style={{ width: "100%", padding: 8 }} /></label>
        <label>Email<input name="email" type="email" required style={{ width: "100%", padding: 8 }} /></label>
        <label>Role<input name="role" placeholder="Bookkeeper, AR/AP, etc." required style={{ width: "100%", padding: 8 }} /></label>
        <label>Message<textarea name="message" rows={5} style={{ width: "100%", padding: 8 }} /></label>
        <button type="submit" style={{ padding: 10, fontWeight: 600 }}>Submit application</button>
      </form>
    </main>
  );
}
