"use client";
import { useState } from "react";
import Script from "next/script";

const plans = [
  { name: "Starter", achPrice: 299, cardPrice: 308, features: ["Bookkeeping support", "Client forms", "Monthly reviews"], priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_STARTER || "" },
  { name: "Standard", achPrice: 499, cardPrice: 514, features: ["Everything in Starter", "Payroll intake", "More workflow support"], priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_STANDARD || "" },
  { name: "Premium", achPrice: 899, cardPrice: 926, features: ["Everything in Standard", "Priority support", "Advanced HR workflows"], priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_PREMIUM || "" }
];

export default function PricingPage() {
  const [loading, setLoading] = useState("");

  async function startCheckout(priceId, planName) {
    const apiBase = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:4000";
    setLoading(planName);
    try {
      const res = await fetch(`${apiBase}/billing/checkout`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ priceId, companyName: "BigBros customer" })
      });
      const data = await res.json();
      if (!res.ok || !data.url) return alert("Checkout error");
      window.location.href = data.url;
    } finally {
      setLoading("");
    }
  }

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: "BigBrosBookkeeping Subscription Plans",
    offers: plans.map((plan) => ({
      "@type": "Offer",
      name: plan.name,
      priceCurrency: "USD",
      lowPrice: String(plan.achPrice),
      highPrice: String(plan.cardPrice)
    }))
  };

  return (
    <main style={{ padding: 24, maxWidth: 1000 }}>
      <Script id="pricing-jsonld" type="application/ld+json">{JSON.stringify(jsonLd)}</Script>
      <h1>Bookkeeping Pricing Plans</h1>
      <p>ACH pricing is lower. Card and wallet pricing covers processing costs.</p>
      <div style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))" }}>
        {plans.map((plan) => (
          <div key={plan.name} style={{ border: "1px solid #ddd", borderRadius: 16, padding: 16 }}>
            <h2>{plan.name}</h2>
            <p><strong>ACH / bank:</strong> ${plan.achPrice}/mo</p>
            <p><strong>Card / wallet:</strong> ${plan.cardPrice}/mo</p>
            <ul>{plan.features.map((f) => <li key={f}>{f}</li>)}</ul>
            <button onClick={() => startCheckout(plan.priceId, plan.name)} disabled={loading === plan.name || !plan.priceId} style={{ padding: 12, fontWeight: 700 }}>
              {loading === plan.name ? "Loading..." : "Subscribe"}
            </button>
            {!plan.priceId ? <p style={{ color: "crimson" }}>Missing price ID in env.</p> : null}
          </div>
        ))}
      </div>
    </main>
  );
}
