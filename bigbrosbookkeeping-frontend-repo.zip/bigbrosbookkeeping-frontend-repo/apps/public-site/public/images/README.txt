Put logo.png, hero.jpg, team.jpg here.
