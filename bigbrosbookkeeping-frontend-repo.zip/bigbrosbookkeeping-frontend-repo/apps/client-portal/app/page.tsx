export default function Page() {
  return (
    <main style={{ padding: 24, maxWidth: 900 }}>
      <h1>Client Portal</h1>
      <ul>
        <li><a href="/forms">Bookkeeping Forms</a></li>
      </ul>
      <p style={{ opacity: 0.7 }}>This is a scaffold. Add full client authentication & file uploads for production.</p>
    </main>
  );
}
