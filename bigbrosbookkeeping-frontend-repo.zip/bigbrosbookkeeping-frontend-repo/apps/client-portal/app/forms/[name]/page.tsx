"use client";
import { useEffect, useMemo, useState } from "react";

type Field = { key: string; label: string; type: string; required?: boolean; options?: string[] };

export default function FormPage({ params }: { params: { name: string } }) {
  const formName = decodeURIComponent(params.name);
  const base = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:4000";

  const [template, setTemplate] = useState<any>(null);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [status, setStatus] = useState<string>("idle");
  const [companyId, setCompanyId] = useState<string>(""); // optional demo

  useEffect(() => {
    (async () => {
      const r = await fetch(`${base}/forms/templates`, { cache: "no-store" });
      const data = await r.json();
      const t = (data.templates || []).find((x: any) => x.name === formName);
      setTemplate(t || null);
    })();
  }, [base, formName]);

  const fields: Field[] = useMemo(() => template?.schemaJson?.fields || [], [template]);

  async function save(submit: boolean) {
    if (!template) return;
    setStatus(submit ? "submitting" : "saving");

    const r = await fetch(`${base}/forms/submissions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        templateId: template.id,
        companyId: companyId || undefined,
        status: submit ? "SUBMITTED" : "DRAFT",
        answers
      })
    });

    const data = await r.json();
    setStatus(r.ok ? "saved" : "error");
    if (!r.ok) alert("Error: " + JSON.stringify(data));
    else alert(submit ? "Submitted!" : "Draft saved!");
  }

  return (
    <main style={{ padding: 24, maxWidth: 1000 }}>
      <a href="/forms" style={{ textDecoration: "none" }}>← Back</a>
      <h1 style={{ marginBottom: 4 }}>{formName}</h1>
      <p style={{ opacity: 0.75, marginTop: 0 }}>Powered by templates in the API. (Demo saves without auth.)</p>

      {!template ? (
        <div style={{ padding: 12, border: "1px solid #ddd", borderRadius: 12 }}>
          Template not found. Run <code>npm run db:seed</code>.
        </div>
      ) : (
        <div style={{ display: "grid", gap: 12, maxWidth: 720 }}>
          <label>
            Company ID (optional demo)
            <input value={companyId} onChange={(e) => setCompanyId(e.target.value)} style={{ width: "100%", padding: 10 }} />
          </label>

          {fields.map((f) => (
            <label key={f.key} style={{ display: "grid", gap: 6 }}>
              <span>
                {f.label} {f.required ? <b style={{ color: "crimson" }}>*</b> : null}
              </span>

              {f.type === "textarea" ? (
                <textarea
                  rows={5}
                  value={answers[f.key] ?? ""}
                  onChange={(e) => setAnswers((a) => ({ ...a, [f.key]: e.target.value }))}
                  style={{ width: "100%", padding: 10 }}
                />
              ) : f.type === "select" ? (
                <select
                  value={answers[f.key] ?? ""}
                  onChange={(e) => setAnswers((a) => ({ ...a, [f.key]: e.target.value }))}
                  style={{ width: "100%", padding: 10 }}
                >
                  <option value="">Select...</option>
                  {(f.options || []).map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              ) : f.type === "checkbox" ? (
                <input
                  type="checkbox"
                  checked={Boolean(answers[f.key])}
                  onChange={(e) => setAnswers((a) => ({ ...a, [f.key]: e.target.checked }))}
                />
              ) : (
                <input
                  type={f.type === "number" ? "number" : f.type === "date" ? "date" : "text"}
                  value={answers[f.key] ?? ""}
                  onChange={(e) => setAnswers((a) => ({ ...a, [f.key]: e.target.value }))}
                  style={{ width: "100%", padding: 10 }}
                />
              )}
            </label>
          ))}

          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={() => save(false)} style={{ padding: 12, fontWeight: 700 }}>
              Save Draft
            </button>
            <button onClick={() => save(true)} style={{ padding: 12, fontWeight: 700 }}>
              Submit
            </button>
          </div>

          <div style={{ opacity: 0.7 }}>Status: {status}</div>
        </div>
      )}
    </main>
  );
}
