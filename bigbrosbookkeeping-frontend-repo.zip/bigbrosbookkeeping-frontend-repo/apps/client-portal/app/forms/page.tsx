export default async function Forms() {
  const base = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:4000";
  const r = await fetch(`${base}/forms/templates`, { cache: "no-store" });
  const data = await r.json();
  const templates = data.templates || [];

  return (
    <main style={{ padding: 24, maxWidth: 1000 }}>
      <h1>Forms</h1>
      <p>Select a form to fill out.</p>
      <div style={{ display: "grid", gap: 10 }}>
        {templates.length === 0 ? (
          <div style={{ padding: 12, border: "1px solid #ddd", borderRadius: 12 }}>
            No templates yet. Run <code>npm run db:seed</code>.
          </div>
        ) : (
          templates.map((t: any) => (
            <a key={t.id} href={"/forms/" + encodeURIComponent(t.name)} style={{ padding: 12, border: "1px solid #ddd", borderRadius: 12, textDecoration: "none" }}>
              <b>{t.name}</b>
              {t.description ? <div style={{ opacity: 0.7 }}>{t.description}</div> : null}
            </a>
          ))
        )}
      </div>
    </main>
  );
}
