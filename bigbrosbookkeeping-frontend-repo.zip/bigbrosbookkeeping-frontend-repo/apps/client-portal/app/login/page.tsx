"use client";
import { useState } from "react";

export default function ClientLogin() {
  const base = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:4000";
  const [email, setEmail] = useState("client@example.com");
  const [password, setPassword] = useState("Password123!");
  const [status, setStatus] = useState("");

  async function login() {
    setStatus("Logging in...");
    const r = await fetch(`${base}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) return setStatus("Error: " + JSON.stringify(data));
    localStorage.setItem("bb_client_token", data.token);
    setStatus("Logged in!");
    window.location.href = "/dashboard";
  }

  return (
    <main style={{ padding: 24, maxWidth: 520 }}>
      <h1>Client Login</h1>
      <div style={{ display: "grid", gap: 12 }}>
        <input value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="Email" style={{ padding: 10 }} />
        <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="Password" style={{ padding: 10 }} />
        <button onClick={login} style={{ padding: 12, fontWeight: 700 }}>Login</button>
        <div>{status}</div>
      </div>
    </main>
  );
}
