"use client";
import { useEffect, useState } from "react";

function token() {
  if (typeof window === "undefined") return "";
  return localStorage.getItem("bb_client_token") || "";
}

async function api(path, init) {
  const base = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:4000";
  const headers = { ...(init?.headers || {}) };
  if (!headers["content-type"] && init?.body) headers["content-type"] = "application/json";
  if (token()) headers["authorization"] = "Bearer " + token();
  const r = await fetch(base + path, { ...init, headers });
  const data = await r.json().catch(()=>({}));
  return { ok: r.ok, data };
}

export default function ClientDashboard() {
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState([]);
  const [status, setStatus] = useState("");
  const [entries, setEntries] = useState([]);
  const [manual, setManual] = useState({ category: "Revenue", amount: "0", note: "" });

  useEffect(() => {
    (async () => {
      const res = await api("/financials/manual");
      if (res.ok) setEntries(res.data.entries || []);
    })();
  }, []);

  async function askAI() {
    const res = await api("/ai/chat", { method: "POST", body: JSON.stringify({ message }) });
    if (res.ok) {
      setChat((x) => [...x, { role: "user", text: message }, { role: "assistant", text: res.data.reply }]);
      setMessage("");
    } else {
      alert("AI error");
    }
  }

  async function connectBank() {
    const res = await api("/plaid/create-link-token", { method: "POST", body: JSON.stringify({ clientName: "BigBrosBookkeeping" }) });
    if (!res.ok) return alert("Could not create bank link token");
    alert("Plaid link token created. In production, open Plaid Link with token: " + res.data.link_token);
  }

  async function saveManual() {
    const res = await api("/financials/manual", {
      method: "POST",
      body: JSON.stringify({ category: manual.category, amount: Number(manual.amount), note: manual.note })
    });
    if (res.ok) {
      setEntries((x) => [res.data.entry, ...x]);
      setStatus("Saved manual financial entry.");
    } else {
      setStatus("Error saving entry.");
    }
  }

  return (
    <main style={{ padding: 24, maxWidth: 1100 }}>
      <h1>Client Dashboard</h1>
      <div style={{ display: "grid", gap: 16, gridTemplateColumns: "1.2fr 1fr" }}>
        <section style={{ border: "1px solid #ddd", borderRadius: 12, padding: 16 }}>
          <h2>Financial Entry</h2>
          <div style={{ display: "grid", gap: 10 }}>
            <input value={manual.category} onChange={(e)=>setManual((m)=>({...m, category: e.target.value}))} placeholder="Category" style={{ padding: 10 }} />
            <input value={manual.amount} onChange={(e)=>setManual((m)=>({...m, amount: e.target.value}))} placeholder="Amount" style={{ padding: 10 }} />
            <textarea value={manual.note} onChange={(e)=>setManual((m)=>({...m, note: e.target.value}))} placeholder="Note" style={{ padding: 10 }} />
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={saveManual} style={{ padding: 12, fontWeight: 700 }}>Save financial entry</button>
              <button onClick={connectBank} style={{ padding: 12, fontWeight: 700 }}>Connect bank with Plaid</button>
            </div>
          </div>
          <p style={{ opacity: 0.7 }}>{status}</p>
        </section>

        <section style={{ border: "1px solid #ddd", borderRadius: 12, padding: 16 }}>
          <h2>AI Bookkeeping Assistant</h2>
          <div style={{ display: "grid", gap: 10, marginBottom: 12 }}>
            {chat.map((m, i) => (
              <div key={i} style={{ padding: 10, borderRadius: 10, background: m.role === "assistant" ? "#f5f5f5" : "#eaf2ff" }}>
                <strong>{m.role}:</strong> {m.text}
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <input value={message} onChange={(e)=>setMessage(e.target.value)} placeholder="Ask about categorizing transactions..." style={{ flex: 1, padding: 10 }} />
            <button onClick={askAI} style={{ padding: 10, fontWeight: 700 }}>Send</button>
          </div>
        </section>
      </div>

      <section style={{ marginTop: 20, border: "1px solid #ddd", borderRadius: 12, padding: 16 }}>
        <h2>Recent Manual Entries</h2>
        <div style={{ display: "grid", gap: 8 }}>
          {entries.map((e) => (
            <div key={e.id} style={{ border: "1px solid #eee", borderRadius: 10, padding: 10 }}>
              <strong>{e.category}</strong> — ${e.amount}
              {e.note ? <div>{e.note}</div> : null}
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
