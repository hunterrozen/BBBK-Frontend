# BigBrosBookkeeping Frontend Repo

This repo contains the frontend apps only:

- `apps/public-site`
- `apps/client-portal`
- `apps/admin-portal`

## Included
- Google Analytics scaffold
- SEO-optimized pricing page
- client login UI
- client dashboard UI
- admin dashboard UI
- live financial feed UI
- AI assistant UI scaffold
- image folders for branding

## Environment
Use `.env.example` and set:
- `NEXT_PUBLIC_API_BASE_URL`
- `NEXT_PUBLIC_WS_URL`
- `NEXT_PUBLIC_CLIENT_PORTAL_URL`
- `NEXT_PUBLIC_ADMIN_PORTAL_URL`
- `NEXT_PUBLIC_STRIPE_PRICE_STARTER`
- `NEXT_PUBLIC_STRIPE_PRICE_STANDARD`
- `NEXT_PUBLIC_STRIPE_PRICE_PREMIUM`
- `NEXT_PUBLIC_GA_MEASUREMENT_ID`

## Recommended deployment
Use AWS Amplify:
- `apps/public-site`
- `apps/client-portal`
- `apps/admin-portal`

Open `CUSTOMIZE-FIRST.md` first.
