# BigBrosBookkeeping — Change These First

This repo is set up so you can change branding, pricing, and deployment without hunting through every file.

## 1) Branding
Change these files first:
- `branding/site.json`
- `apps/public-site/app/page.tsx`
- `apps/admin-portal/app/layout.tsx`
- `apps/client-portal/app/layout.tsx`

## 2) Pricing
Change these files:
- `config/pricing.json`
- `apps/public-site/app/pricing/page.tsx`
- `apps/admin-portal/app/pricing/page.tsx`
- payment env vars in `.env`

## 3) Payment / Billing
Change:
- `.env`
- `services/api/src/routes/billing.ts`

## 4) AWS
Change:
- `infra/cdk/lib/bigbros-stack.ts`
- `amplify.yml`

## 5) Images / Logo
Put images here:
- `apps/public-site/public/images/`
- `apps/client-portal/public/images/`
- `apps/admin-portal/public/images/`

## 6) Forms
Change bookkeeping forms here:
- `services/api/src/seed/forms.ts`
- Admin form builder: `/forms/templates`

## 7) Before uploading to AWS
- Fill in `.env`
- Replace placeholder URLs
- Replace demo auth secrets
- Add real database + payment credentials


## 8) New upgraded features
Added feature files:
- Client login: `apps/client-portal/app/login/page.tsx`
- Client dashboard: `apps/client-portal/app/dashboard/page.tsx`
- Admin live financials: `apps/admin-portal/app/live-financials/page.tsx`
- AI assistant backend: `services/api/src/routes/ai.ts`
- Plaid scaffolds: `services/api/src/routes/plaid.ts`
- Manual financial entry routes: `services/api/src/routes/financials.ts`

## 9) Live feed for client-entered financials
Current repo includes:
- manual financial entries route
- admin live financials page
- websocket broadcast service scaffold

To make it fully live in production:
- post financial events to the websocket `/broadcast` endpoint from the API after saves
- or replace with a shared pub/sub layer
